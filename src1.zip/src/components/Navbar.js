import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { auth } from "../firebase"; // Import Firebase Auth

function Navbar() {
  const [userEmail, setUserEmail] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false); // State for toggling menu

  // Fetch Current User's Email
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        const emailPrefix = user.email.split("@")[0]; // Get part before @
        setUserEmail(emailPrefix);
      } else {
        setUserEmail(null);
      }
    });

    return () => unsubscribe(); // Clean up listener on unmount
  }, []);

  // Close the menu when a link is clicked
  const handleLinkClick = () => {
    setMenuOpen(false);
  };

  return (
    <nav className="navbar">
      <h1 className="navbar-logo">E-Commerce Store</h1>
      <button
        className="navbar-toggle"
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label="Toggle menu"
      >
        ☰
      </button>
      <div className={`navbar-links-container ${menuOpen ? "open" : ""}`}>
        <ul className="navbar-links">
          <li>
            <Link to="/" onClick={handleLinkClick}>
              Home
            </Link>
          </li>
          <li>
            <Link to="/login" onClick={handleLinkClick}>
              Login
            </Link>
          </li>
          <li>
            <Link to="/register" onClick={handleLinkClick}>
              Register
            </Link>
          </li>
          <li>
            <Link to="/cart" onClick={handleLinkClick}>
              Cart
            </Link>
          </li>
                     
        </ul>
        {userEmail && (
          <div className="user-email">
            Logged in as: <strong>{userEmail}</strong>
          </div>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
