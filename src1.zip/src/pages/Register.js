import { useState } from "react";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase";
import { useNavigate } from "react-router-dom";
import "../styles.css";

function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agree, setAgree] = useState(false);
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!agree) {
      alert("You must agree to the terms and conditions.");
      return;
    }
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      alert("Registration Successful!");
      navigate("/login");
    } catch (error) {
      console.error("Error Registering User:", error);
      alert(error.message);
    }
  };

  return (
    <div className="form-container">
      <form className="form" onSubmit={handleRegister}>
        <h2 className="form-title">Register</h2>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="form-input"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="form-input"
        />
        <div className="checkbox-container">
          <input
            type="checkbox"
            id="terms"
            checked={agree}
            onChange={() => setAgree(!agree)}
          />
          <label htmlFor="terms">I agree to the terms and conditions</label>
        </div>
        <button type="submit" className="form-button">Register</button>
      </form>
    </div>
  );
}

export default Register;
